#!/bin/bash

BASE_URL="http://localhost:8000/api"

echo "========================================"
echo "Testing Job Board Backend API"
echo "========================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test 1: Register Seeker
echo -e "\n${YELLOW}Test 1: Register Seeker${NC}"
REGISTER_RESPONSE=$(curl -s -X POST $BASE_URL/auth/register/ \
  -H "Content-Type: application/json" \
  -d '{"email":"testseeker@test.com","full_name":"Test Seeker","password":"testpass123","role":"SEEKER"}')

echo "$REGISTER_RESPONSE" | python3 -m json.tool

# Test 2: Login Seeker (using seeded data)
echo -e "\n${YELLOW}Test 2: Login Seeker (seeker1@example.com)${NC}"
LOGIN_RESPONSE=$(curl -s -X POST $BASE_URL/auth/login/ \
  -H "Content-Type: application/json" \
  -d '{"email":"seeker1@example.com","password":"password123"}')

echo "$LOGIN_RESPONSE" | python3 -m json.tool

# Extract token using python
SEEKER_TOKEN=$(echo "$LOGIN_RESPONSE" | python3 -c "import sys, json; print(json.load(sys.stdin).get('access', ''))" 2>/dev/null)

if [ -z "$SEEKER_TOKEN" ]; then
    echo -e "${RED}Failed to get seeker token. Please check if database is seeded.${NC}"
    echo -e "${YELLOW}Run: python manage.py seed_data${NC}"
    exit 1
else
    echo -e "${GREEN}Token obtained successfully${NC}"
fi

# Test 3: View Public Jobs
echo -e "\n${YELLOW}Test 3: View Public Jobs${NC}"
curl -s -X GET $BASE_URL/jobs/public/ | python3 -m json.tool

# Test 4: Apply for Job
echo -e "\n${YELLOW}Test 4: Apply for Job (Job ID: 1)${NC}"
APPLY_RESPONSE=$(curl -s -X POST $BASE_URL/applications/apply/ \
  -H "Authorization: Bearer $SEEKER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"job":1,"resume_url":"https://example.com/my-resume.pdf"}')

echo "$APPLY_RESPONSE" | python3 -m json.tool

# Test 5: Try to apply again (should fail)
echo -e "\n${YELLOW}Test 5: Try to Apply Again (Should Fail)${NC}"
curl -s -X POST $BASE_URL/applications/apply/ \
  -H "Authorization: Bearer $SEEKER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"job":1,"resume_url":"https://example.com/my-resume.pdf"}' \
  | python3 -m json.tool

# Test 6: Login Employer
echo -e "\n${YELLOW}Test 6: Login Employer (employer1@example.com)${NC}"
EMPLOYER_LOGIN=$(curl -s -X POST $BASE_URL/auth/login/ \
  -H "Content-Type: application/json" \
  -d '{"email":"employer1@example.com","password":"password123"}')

echo "$EMPLOYER_LOGIN" | python3 -m json.tool

EMPLOYER_TOKEN=$(echo "$EMPLOYER_LOGIN" | python3 -c "import sys, json; print(json.load(sys.stdin).get('access', ''))" 2>/dev/null)

if [ -z "$EMPLOYER_TOKEN" ]; then
    echo -e "${RED}Failed to get employer token${NC}"
    exit 1
else
    echo -e "${GREEN}Employer token obtained${NC}"
fi

# Test 7: View Dashboard Stats
echo -e "\n${YELLOW}Test 7: View Employer Dashboard Stats${NC}"
curl -s -X GET $BASE_URL/applications/employer/dashboard/ \
  -H "Authorization: Bearer $EMPLOYER_TOKEN" \
  | python3 -m json.tool

# Test 8: View Employer's Jobs
echo -e "\n${YELLOW}Test 8: View Employer's Jobs${NC}"
curl -s -X GET $BASE_URL/jobs/employer/ \
  -H "Authorization: Bearer $EMPLOYER_TOKEN" \
  | python3 -m json.tool

# Test 9: Create New Job
echo -e "\n${YELLOW}Test 9: Create New Job${NC}"
CREATE_JOB=$(curl -s -X POST $BASE_URL/jobs/employer/ \
  -H "Authorization: Bearer $EMPLOYER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Backend Developer",
    "description": "Testing job creation via API",
    "location": "Remote",
    "employment_type": "FULL_TIME",
    "application_deadline": "2025-06-30T23:59:59Z"
  }')

echo "$CREATE_JOB" | python3 -m json.tool

# Extract new job ID
NEW_JOB_ID=$(echo "$CREATE_JOB" | python3 -c "import sys, json; print(json.load(sys.stdin).get('id', ''))" 2>/dev/null)

# Test 10: View Applications for Job 1
echo -e "\n${YELLOW}Test 10: View Applications for Job 1${NC}"
curl -s -X GET $BASE_URL/applications/job/1/ \
  -H "Authorization: Bearer $EMPLOYER_TOKEN" \
  | python3 -m json.tool

# Test 11: Update Application Status to ACCEPTED
echo -e "\n${YELLOW}Test 11: Accept Application (ID: 1)${NC}"
curl -s -X PATCH $BASE_URL/applications/1/status/ \
  -H "Authorization: Bearer $EMPLOYER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"status": "ACCEPTED"}' \
  | python3 -m json.tool

# Test 12: Update Application Status to REJECTED
echo -e "\n${YELLOW}Test 12: Reject Application (ID: 2)${NC}"
curl -s -X PATCH $BASE_URL/applications/2/status/ \
  -H "Authorization: Bearer $EMPLOYER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"status": "REJECTED"}' \
  | python3 -m json.tool

# Test 13: Update Job (if new job was created)
if [ ! -z "$NEW_JOB_ID" ]; then
    echo -e "\n${YELLOW}Test 13: Update Job (ID: $NEW_JOB_ID)${NC}"
    curl -s -X PUT $BASE_URL/jobs/employer/$NEW_JOB_ID/ \
      -H "Authorization: Bearer $EMPLOYER_TOKEN" \
      -H "Content-Type: application/json" \
      -d '{
        "title": "Senior Backend Developer (Updated)",
        "description": "Updated job description",
        "location": "San Francisco, CA",
        "employment_type": "FULL_TIME",
        "application_deadline": "2025-07-31T23:59:59Z"
      }' \
      | python3 -m json.tool
fi

# Test 14: Try Seeker creating job (should fail)
echo -e "\n${YELLOW}Test 14: Seeker Tries to Create Job (Should Fail)${NC}"
curl -s -X POST $BASE_URL/jobs/employer/ \
  -H "Authorization: Bearer $SEEKER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "This Should Fail",
    "description": "Seekers cannot create jobs",
    "location": "Remote",
    "employment_type": "FULL_TIME",
    "application_deadline": "2025-06-30T23:59:59Z"
  }' \
  | python3 -m json.tool

# Test 15: Try Employer applying for job (should fail)
echo -e "\n${YELLOW}Test 15: Employer Tries to Apply (Should Fail)${NC}"
curl -s -X POST $BASE_URL/applications/apply/ \
  -H "Authorization: Bearer $EMPLOYER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"job":1,"resume_url":"https://example.com/resume.pdf"}' \
  | python3 -m json.tool

echo -e "\n${GREEN}========================================"
echo "All tests completed!"
echo "========================================${NC}"